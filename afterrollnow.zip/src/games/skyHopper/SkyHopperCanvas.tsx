/**
 * Sky Hopper - Main Gameplay Canvas & Physics Engine
 * Faithfully matches "sky hopper.mp4" visual aesthetics and feel.
 */

import React, { useRef, useEffect, useCallback } from 'react';
import { SkyHopperLevelConfig, BirdEntity, ActivePipe, Particle, FloatingText } from './types';
import { skyHopperAudio } from './audio';

interface SkyHopperCanvasProps {
  levelConfig: SkyHopperLevelConfig;
  isPaused: boolean;
  onScoreUpdate: (score: number) => void;
  onCoinCollected: (coinsCount: number) => void;
  onGameOver: (finalScore: number, coinsEarned: number) => void;
  onLevelComplete: (finalScore: number, coinsEarned: number) => void;
  onPauseToggle: () => void;
}

export const SkyHopperCanvas: React.FC<SkyHopperCanvasProps> = ({
  levelConfig,
  isPaused,
  onScoreUpdate,
  onCoinCollected,
  onGameOver,
  onLevelComplete,
  onPauseToggle,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Mutable game state inside refs to avoid re-renders during high-frequency 60fps loop
  const gameStateRef = useRef({
    score: 0,
    coinsEarned: 0,
    isAlive: true,
    isComplete: false,
    hasStarted: false,
    distanceScrolled: 0,
    cloudOffset: 0,
    skylineOffset: 0,
    groundOffset: 0,
    nextObstacleIndex: 0,
    pipes: [] as ActivePipe[],
    particles: [] as Particle[],
    floatingTexts: [] as FloatingText[],
    bird: {
      x: 100,
      y: 280,
      vy: 0,
      rotation: 0,
      radius: 13,
      wingPhase: 0,
      isAlive: true,
    } as BirdEntity,
  });

  // Callbacks ref to always call the latest props without triggering effect restarts
  const callbacksRef = useRef({
    onScoreUpdate,
    onCoinCollected,
    onGameOver,
    onLevelComplete,
  });
  useEffect(() => {
    callbacksRef.current = {
      onScoreUpdate,
      onCoinCollected,
      onGameOver,
      onLevelComplete,
    };
  }, [onScoreUpdate, onCoinCollected, onGameOver, onLevelComplete]);

  // Jump / Flap handler
  const handleFlap = useCallback(() => {
    const s = gameStateRef.current;
    if (!s.isAlive || s.isComplete || isPaused) return;

    s.hasStarted = true;
    s.bird.vy = levelConfig.jumpForce;
    s.bird.rotation = -0.45; // tilt up instantly
    s.bird.wingPhase = Math.PI; // trigger wing flap
    skyHopperAudio.playFlap();

    // Spawn tiny air puff particles behind bird
    for (let i = 0; i < 3; i++) {
      s.particles.push({
        x: s.bird.x - 12,
        y: s.bird.y + (Math.random() * 8 - 4),
        vx: -1.5 - Math.random() * 1.5,
        vy: (Math.random() - 0.5) * 1.2,
        size: 3 + Math.random() * 2,
        color: 'rgba(255, 255, 255, 0.7)',
        alpha: 0.8,
        life: 0,
        maxLife: 18,
      });
    }
  }, [isPaused, levelConfig.jumpForce]);

  // Keyboard controls (Spacebar or Up Arrow)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'Space' || e.code === 'ArrowUp') {
        e.preventDefault();
        handleFlap();
      } else if (e.code === 'KeyP') {
        e.preventDefault();
        onPauseToggle();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleFlap, onPauseToggle]);

  // Main Game Loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    const VIRTUAL_WIDTH = 380;
    const VIRTUAL_HEIGHT = 620;
    const GROUND_HEIGHT = 100;
    const PLAYABLE_HEIGHT = VIRTUAL_HEIGHT - GROUND_HEIGHT;

    // Reset game state for this level
    const s = gameStateRef.current;
    s.score = 0;
    s.coinsEarned = 0;
    s.isAlive = true;
    s.isComplete = false;
    s.hasStarted = false;
    s.distanceScrolled = 0;
    s.cloudOffset = 0;
    s.skylineOffset = 0;
    s.groundOffset = 0;
    s.nextObstacleIndex = 0;
    s.pipes = [];
    s.particles = [];
    s.floatingTexts = [];
    s.bird = {
      x: 95,
      y: 270,
      vy: 0,
      rotation: 0,
      radius: 13,
      wingPhase: 0,
      isAlive: true,
    };

    // Pre-seed first 2 obstacles from level configuration
    const initialSpawnX = VIRTUAL_WIDTH + 60;
    for (let i = 0; i < 2 && i < levelConfig.obstacles.length; i++) {
      const obs = levelConfig.obstacles[i];
      const gap = levelConfig.gapSize;
      const topHeight = Math.max(50, Math.min(PLAYABLE_HEIGHT - gap - 50, (obs.topHeightPercent / 100) * PLAYABLE_HEIGHT));
      const bottomY = topHeight + gap;
      const coinY = topHeight + gap / 2 + (obs.coinOffsetPercent || 0);

      s.pipes.push({
        index: i,
        x: initialSpawnX + i * levelConfig.pipeSpacing,
        topHeight,
        bottomY,
        gap,
        width: 58,
        passed: false,
        hasCoin: obs.hasCoin ?? true,
        coinCollected: false,
        coinX: initialSpawnX + i * levelConfig.pipeSpacing + 29,
        coinY,
        coinRadius: 11,
      });
      s.nextObstacleIndex = i + 1;
    }

    // Drawing Helpers ---------------------------------------------------------
    
    // Pixel-perfect Cloud
    const drawCloud = (cx: number, cy: number, scale: number = 1) => {
      ctx.save();
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(cx, cy, 20 * scale, 0, Math.PI * 2);
      ctx.arc(cx + 18 * scale, cy - 8 * scale, 24 * scale, 0, Math.PI * 2);
      ctx.arc(cx + 42 * scale, cy, 18 * scale, 0, Math.PI * 2);
      ctx.arc(cx + 25 * scale, cy + 8 * scale, 20 * scale, 0, Math.PI * 2);
      ctx.fill();

      // Flat bottom puff
      ctx.beginPath();
      ctx.roundRect(cx - 15 * scale, cy + 2 * scale, 65 * scale, 16 * scale, 8 * scale);
      ctx.fill();
      ctx.restore();
    };

    // Distant City Skyline (Matching the video)
    const drawSkyline = (offset: number) => {
      ctx.save();
      const baseGroundY = PLAYABLE_HEIGHT;
      const cityColor = '#7bcbb9';
      const windowColor = '#a8e4d5';
      const buildingWidth = 32;
      const heights = [90, 130, 110, 150, 80, 120, 140, 100, 160, 115, 95, 135];
      const startIdx = Math.floor(offset / buildingWidth);
      const shiftX = -(offset % buildingWidth);

      for (let i = -1; i < Math.ceil(VIRTUAL_WIDTH / buildingWidth) + 2; i++) {
        const idx = (startIdx + i + 1000) % heights.length;
        const bh = heights[idx];
        const bx = i * buildingWidth + shiftX;
        const by = baseGroundY - bh;

        ctx.fillStyle = cityColor;
        ctx.fillRect(bx, by, buildingWidth - 2, bh);

        // Little windows
        ctx.fillStyle = windowColor;
        for (let wy = by + 12; wy < baseGroundY - 15; wy += 16) {
          ctx.fillRect(bx + 5, wy, 5, 7);
          ctx.fillRect(bx + 16, wy, 5, 7);
        }
      }
      ctx.restore();
    };

    // Green Foliage / Bush layer
    const drawBushes = (offset: number) => {
      ctx.save();
      const baseGroundY = PLAYABLE_HEIGHT;
      const bushColor = '#59a639';
      const bushDark = '#488c2b';
      const bushWidth = 40;
      const shiftX = -(offset % bushWidth);

      for (let i = -1; i < Math.ceil(VIRTUAL_WIDTH / bushWidth) + 2; i++) {
        const bx = i * bushWidth + shiftX + 20;
        ctx.fillStyle = bushDark;
        ctx.beginPath();
        ctx.arc(bx - 4, baseGroundY, 22, Math.PI, 0);
        ctx.fill();

        ctx.fillStyle = bushColor;
        ctx.beginPath();
        ctx.arc(bx, baseGroundY, 20, Math.PI, 0);
        ctx.fill();
      }
      ctx.restore();
    };

    // Authentic Ground with diagonal hazard grass stripes and sand soil
    const drawGround = (offset: number) => {
      ctx.save();
      const groundY = PLAYABLE_HEIGHT;

      // Top grass band
      ctx.fillStyle = '#8dc63f';
      ctx.fillRect(0, groundY, VIRTUAL_WIDTH, 14);

      // Diagonal grass stripes (matching video)
      ctx.fillStyle = '#73a528';
      const stripeSpacing = 16;
      const stripeShift = -(offset % stripeSpacing);
      ctx.beginPath();
      for (let x = stripeShift - 20; x < VIRTUAL_WIDTH + 20; x += stripeSpacing) {
        ctx.moveTo(x, groundY);
        ctx.lineTo(x + 10, groundY);
        ctx.lineTo(x, groundY + 14);
        ctx.lineTo(x - 10, groundY + 14);
      }
      ctx.fill();

      // Thin separator line
      ctx.fillStyle = '#55821c';
      ctx.fillRect(0, groundY + 14, VIRTUAL_WIDTH, 2);

      // Sand / Dirt base
      ctx.fillStyle = '#ded895';
      ctx.fillRect(0, groundY + 16, VIRTUAL_WIDTH, GROUND_HEIGHT - 16);

      // Subtle horizontal sand strata
      ctx.fillStyle = '#cfc983';
      ctx.fillRect(0, groundY + 28, VIRTUAL_WIDTH, 4);
      ctx.fillRect(0, groundY + 54, VIRTUAL_WIDTH, 3);
      ctx.fillRect(0, groundY + 76, VIRTUAL_WIDTH, 3);
      ctx.restore();
    };

    // Classic Green Retro Pipe (Identical to reference video)
    const drawPipe = (p: ActivePipe) => {
      ctx.save();
      const pipeWidth = p.width;
      const collarWidth = pipeWidth + 8;
      const collarHeight = 24;
      const collarOffset = 4;

      // Colors
      const pipeGreen = '#73bf2e';
      const pipeLight = '#8fe038';
      const pipeDark = '#558a20';
      const pipeOutline = '#274b0c';

      // 1. TOP PIPE (descending from top)
      if (p.topHeight > 0) {
        // Body outline
        ctx.fillStyle = pipeOutline;
        ctx.fillRect(p.x, 0, pipeWidth, p.topHeight);

        // Body fill
        ctx.fillStyle = pipeGreen;
        ctx.fillRect(p.x + 2, 0, pipeWidth - 4, p.topHeight);

        // Highlight stripe (left)
        ctx.fillStyle = pipeLight;
        ctx.fillRect(p.x + 6, 0, 7, p.topHeight);

        // Shadow stripe (right)
        ctx.fillStyle = pipeDark;
        ctx.fillRect(p.x + pipeWidth - 11, 0, 7, p.topHeight);

        // Collar Cap at bottom of top pipe
        const collarX = p.x - collarOffset;
        const collarY = p.topHeight - collarHeight;

        ctx.fillStyle = pipeOutline;
        ctx.fillRect(collarX, collarY, collarWidth, collarHeight);

        ctx.fillStyle = pipeGreen;
        ctx.fillRect(collarX + 2, collarY + 2, collarWidth - 4, collarHeight - 4);

        ctx.fillStyle = pipeLight;
        ctx.fillRect(collarX + 6, collarY + 2, 8, collarHeight - 4);

        ctx.fillStyle = pipeDark;
        ctx.fillRect(collarX + collarWidth - 12, collarY + 2, 8, collarHeight - 4);
      }

      // 2. BOTTOM PIPE (ascending from bottom)
      const bottomHeight = PLAYABLE_HEIGHT - p.bottomY;
      if (bottomHeight > 0) {
        // Collar Cap at top of bottom pipe
        const collarX = p.x - collarOffset;
        const collarY = p.bottomY;

        ctx.fillStyle = pipeOutline;
        ctx.fillRect(collarX, collarY, collarWidth, collarHeight);

        ctx.fillStyle = pipeGreen;
        ctx.fillRect(collarX + 2, collarY + 2, collarWidth - 4, collarHeight - 4);

        ctx.fillStyle = pipeLight;
        ctx.fillRect(collarX + 6, collarY + 2, 8, collarHeight - 4);

        ctx.fillStyle = pipeDark;
        ctx.fillRect(collarX + collarWidth - 12, collarY + 2, 8, collarHeight - 4);

        // Body beneath collar
        const bodyY = p.bottomY + collarHeight;
        const bodyHeight = PLAYABLE_HEIGHT - bodyY;

        ctx.fillStyle = pipeOutline;
        ctx.fillRect(p.x, bodyY, pipeWidth, bodyHeight);

        ctx.fillStyle = pipeGreen;
        ctx.fillRect(p.x + 2, bodyY, pipeWidth - 4, bodyHeight);

        ctx.fillStyle = pipeLight;
        ctx.fillRect(p.x + 6, bodyY, 7, bodyHeight);

        ctx.fillStyle = pipeDark;
        ctx.fillRect(p.x + pipeWidth - 11, bodyY, 7, bodyHeight);
      }

      ctx.restore();
    };

    // Golden Coin (Matching video reference)
    const drawCoin = (coinX: number, coinY: number) => {
      ctx.save();
      // Outer drop glow
      ctx.fillStyle = 'rgba(245, 158, 11, 0.3)';
      ctx.beginPath();
      ctx.arc(coinX, coinY, 13, 0, Math.PI * 2);
      ctx.fill();

      // Outer rim
      ctx.fillStyle = '#d97706';
      ctx.beginPath();
      ctx.arc(coinX, coinY, 10.5, 0, Math.PI * 2);
      ctx.fill();

      // Gold core
      ctx.fillStyle = '#fbbf24';
      ctx.beginPath();
      ctx.arc(coinX, coinY, 9, 0, Math.PI * 2);
      ctx.fill();

      // Inner shiny star/diamond
      ctx.fillStyle = '#fffbeb';
      ctx.beginPath();
      ctx.moveTo(coinX, coinY - 5);
      ctx.lineTo(coinX + 4, coinY);
      ctx.lineTo(coinX, coinY + 5);
      ctx.lineTo(coinX - 4, coinY);
      ctx.closePath();
      ctx.fill();

      // Specular highlight dot
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(coinX - 3, coinY - 3, 2, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    };

    // Authentic Blue Pixel Bird (Matching video reference)
    const drawBird = (b: BirdEntity) => {
      ctx.save();
      ctx.translate(b.x, b.y);
      ctx.rotate(b.rotation);

      // Bird body dimensions: approx 34w x 24h
      const outlineColor = '#17202a';
      const blueBody = '#38bdf8';
      const blueDark = '#0284c7';
      const bellyWhite = '#ffffff';
      const beakOrange = '#f97316';
      const beakDark = '#ea580c';

      // 1. Tail feather
      ctx.fillStyle = outlineColor;
      ctx.fillRect(-17, -2, 6, 7);
      ctx.fillStyle = blueDark;
      ctx.fillRect(-15, -1, 4, 5);

      // 2. Main Body (Rounded pill with pixel-arcade charm)
      ctx.fillStyle = outlineColor;
      ctx.beginPath();
      ctx.ellipse(0, 0, 15, 12, 0, 0, Math.PI * 2);
      ctx.fill();

      // Body fill
      ctx.fillStyle = blueBody;
      ctx.beginPath();
      ctx.ellipse(0, 0, 13.5, 10.5, 0, 0, Math.PI * 2);
      ctx.fill();

      // 3. White underbelly
      ctx.fillStyle = bellyWhite;
      ctx.beginPath();
      ctx.ellipse(-2, 4, 8, 5, 0.2, 0, Math.PI * 2);
      ctx.fill();

      // 4. Wing with animated flap flutter
      const wingYOffset = Math.sin(b.wingPhase) * 4;
      ctx.save();
      ctx.translate(-4, -1 + wingYOffset);
      ctx.rotate(Math.sin(b.wingPhase) * 0.35);

      ctx.fillStyle = outlineColor;
      ctx.beginPath();
      ctx.ellipse(0, 0, 7.5, 4.5, -0.2, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.ellipse(0, 0, 6, 3.5, -0.2, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = blueDark;
      ctx.fillRect(-3, -1, 3, 2);
      ctx.restore();

      // 5. Large Round White Eye with Black Pupil (Matching video)
      ctx.fillStyle = outlineColor;
      ctx.beginPath();
      ctx.arc(6, -4, 5.5, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(6, -4, 4.2, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = outlineColor;
      ctx.beginPath();
      ctx.arc(7.2, -4, 2.2, 0, Math.PI * 2);
      ctx.fill();

      // White eye glint
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(6.5, -5, 1, 0, Math.PI * 2);
      ctx.fill();

      // 6. Orange Beak
      ctx.fillStyle = outlineColor;
      ctx.beginPath();
      ctx.moveTo(11, -2);
      ctx.lineTo(19, 1);
      ctx.lineTo(11, 5);
      ctx.closePath();
      ctx.fill();

      ctx.fillStyle = beakOrange;
      ctx.beginPath();
      ctx.moveTo(11, -1);
      ctx.lineTo(17.5, 1);
      ctx.lineTo(11, 4);
      ctx.closePath();
      ctx.fill();

      // Beak mouth crease
      ctx.fillStyle = beakDark;
      ctx.fillRect(11, 1.5, 5, 1);

      ctx.restore();
    };

    // Game Update Loop --------------------------------------------------------
    const render = () => {
      // Clear canvas with bright blue retro sky
      ctx.fillStyle = '#4ec0ca';
      ctx.fillRect(0, 0, VIRTUAL_WIDTH, VIRTUAL_HEIGHT);

      // Render Parallax Background
      // 1. Soft Clouds (moving slowly)
      const cloudX1 = ((30 - s.cloudOffset) % (VIRTUAL_WIDTH + 140)) - 60;
      const cloudX2 = ((220 - s.cloudOffset * 0.8) % (VIRTUAL_WIDTH + 140)) - 60;
      drawCloud(cloudX1, 130, 0.85);
      drawCloud(cloudX2, 175, 0.7);

      // 2. City Skyline
      drawSkyline(s.skylineOffset);

      // 3. Green Bushes
      drawBushes(s.groundOffset * 0.6);

      // Update physics if not paused and alive
      if (!isPaused && s.isAlive && !s.isComplete) {
        if (s.hasStarted) {
          // Gravity pull
          s.bird.vy += levelConfig.gravity;
          s.bird.y += s.bird.vy;

          // Smooth rotation: nose-up on flap, smooth gradual dive on fall
          if (s.bird.vy < 0) {
            // Ascending
            s.bird.rotation = Math.max(-0.45, s.bird.rotation - 0.08);
          } else {
            // Descending
            s.bird.rotation = Math.min(1.2, s.bird.rotation + 0.045 * (s.bird.vy / 4));
          }

          // Flap animation phase decays to glide
          s.bird.wingPhase += 0.28;

          // Parallax and scroll progress
          s.distanceScrolled += levelConfig.speed;
          s.cloudOffset += levelConfig.speed * 0.2;
          s.skylineOffset += levelConfig.speed * 0.45;
          s.groundOffset += levelConfig.speed;

          // Ceiling boundary
          if (s.bird.y < s.bird.radius + 10) {
            s.bird.y = s.bird.radius + 10;
            s.bird.vy = 0;
          }

          // Ground collision
          if (s.bird.y + s.bird.radius >= PLAYABLE_HEIGHT) {
            s.bird.y = PLAYABLE_HEIGHT - s.bird.radius;
            s.isAlive = false;
            skyHopperAudio.playHit();
            skyHopperAudio.playFall();
            callbacksRef.current.onGameOver(s.score, s.coinsEarned);
          }

          // Update Pipes
          for (let i = s.pipes.length - 1; i >= 0; i--) {
            const p = s.pipes[i];
            p.x -= levelConfig.speed;
            p.coinX -= levelConfig.speed;

            // Score checking: when pipe passes player center
            if (!p.passed && p.x + p.width / 2 < s.bird.x) {
              p.passed = true;
              s.score += 1;
              callbacksRef.current.onScoreUpdate(s.score);
              skyHopperAudio.playPoint();

              // Check if Level Complete target reached!
              if (s.score >= levelConfig.targetScore) {
                s.isComplete = true;
                skyHopperAudio.playLevelComplete();
                callbacksRef.current.onLevelComplete(s.score, s.coinsEarned);
              }
            }

            // Coin collection checking
            if (p.hasCoin && !p.coinCollected) {
              const dx = s.bird.x - p.coinX;
              const dy = s.bird.y - p.coinY;
              const dist = Math.sqrt(dx * dx + dy * dy);
              if (dist < s.bird.radius + p.coinRadius + 6) {
                p.coinCollected = true;
                s.coinsEarned += 1;
                callbacksRef.current.onCoinCollected(s.coinsEarned);
                skyHopperAudio.playCoin();

                // Sparkle burst
                for (let k = 0; k < 10; k++) {
                  const angle = Math.random() * Math.PI * 2;
                  const speed = 1.5 + Math.random() * 2.5;
                  s.particles.push({
                    x: p.coinX,
                    y: p.coinY,
                    vx: Math.cos(angle) * speed,
                    vy: Math.sin(angle) * speed,
                    size: 2.5 + Math.random() * 2.5,
                    color: '#fef08a',
                    alpha: 1,
                    life: 0,
                    maxLife: 22,
                  });
                }

                // Floating +1
                s.floatingTexts.push({
                  x: p.coinX - 8,
                  y: p.coinY - 12,
                  text: '+1',
                  color: '#fbbf24',
                  alpha: 1,
                  life: 0,
                });
              }
            }

            // Collision Detection with Pipe (Fair hitbox with 3px inset)
            if (s.isAlive && !s.isComplete) {
              const birdLeft = s.bird.x - s.bird.radius + 3;
              const birdRight = s.bird.x + s.bird.radius - 3;
              const birdTop = s.bird.y - s.bird.radius + 3;
              const birdBottom = s.bird.y + s.bird.radius - 3;

              const pipeLeft = p.x - 2;
              const pipeRight = p.x + p.width + 2;

              if (birdRight > pipeLeft && birdLeft < pipeRight) {
                // Top pipe collision
                if (birdTop < p.topHeight) {
                  s.isAlive = false;
                  skyHopperAudio.playHit();
                  skyHopperAudio.playFall();
                  callbacksRef.current.onGameOver(s.score, s.coinsEarned);
                }
                // Bottom pipe collision
                if (birdBottom > p.bottomY) {
                  s.isAlive = false;
                  skyHopperAudio.playHit();
                  skyHopperAudio.playFall();
                  callbacksRef.current.onGameOver(s.score, s.coinsEarned);
                }
              }
            }

            // Remove offscreen pipes
            if (p.x + p.width < -50) {
              s.pipes.splice(i, 1);
            }
          }

          // Spawn next deterministic pipe if needed
          const lastPipe = s.pipes[s.pipes.length - 1];
          if (!lastPipe || lastPipe.x <= VIRTUAL_WIDTH + 60 - levelConfig.pipeSpacing) {
            if (s.nextObstacleIndex < levelConfig.obstacles.length) {
              const obs = levelConfig.obstacles[s.nextObstacleIndex];
              const gap = levelConfig.gapSize;
              const topHeight = Math.max(50, Math.min(PLAYABLE_HEIGHT - gap - 50, (obs.topHeightPercent / 100) * PLAYABLE_HEIGHT));
              const bottomY = topHeight + gap;
              const coinY = topHeight + gap / 2 + (obs.coinOffsetPercent || 0);
              const spawnX = lastPipe ? lastPipe.x + levelConfig.pipeSpacing : VIRTUAL_WIDTH + 50;

              s.pipes.push({
                index: s.nextObstacleIndex,
                x: spawnX,
                topHeight,
                bottomY,
                gap,
                width: 58,
                passed: false,
                hasCoin: obs.hasCoin ?? true,
                coinCollected: false,
                coinX: spawnX + 29,
                coinY,
                coinRadius: 11,
              });
              s.nextObstacleIndex++;
            }
          }
        } else {
          // Pre-start gentle hover float animation
          s.bird.y = 270 + Math.sin(Date.now() / 250) * 8;
          s.bird.wingPhase += 0.15;
          s.groundOffset += 1.2;
          s.cloudOffset += 0.2;
        }
      }

      // Render Active Pipes
      s.pipes.forEach(drawPipe);

      // Render Coins
      s.pipes.forEach((p) => {
        if (p.hasCoin && !p.coinCollected) {
          drawCoin(p.coinX, p.coinY);
        }
      });

      // Render Particles
      for (let i = s.particles.length - 1; i >= 0; i--) {
        const pt = s.particles[i];
        pt.x += pt.vx;
        pt.y += pt.vy;
        pt.life++;
        pt.alpha = 1 - pt.life / pt.maxLife;

        ctx.save();
        ctx.fillStyle = pt.color;
        ctx.globalAlpha = Math.max(0, pt.alpha);
        ctx.beginPath();
        ctx.arc(pt.x, pt.y, pt.size, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();

        if (pt.life >= pt.maxLife) {
          s.particles.splice(i, 1);
        }
      }

      // Render Floating Texts
      for (let i = s.floatingTexts.length - 1; i >= 0; i--) {
        const ft = s.floatingTexts[i];
        ft.y -= 1.2;
        ft.life++;
        ft.alpha = Math.max(0, 1 - ft.life / 30);

        ctx.save();
        ctx.font = 'bold 16px "Fredoka", sans-serif';
        ctx.fillStyle = ft.color;
        ctx.globalAlpha = ft.alpha;
        ctx.shadowColor = '#000000';
        ctx.shadowBlur = 4;
        ctx.fillText(ft.text, ft.x, ft.y);
        ctx.restore();

        if (ft.life >= 30) {
          s.floatingTexts.splice(i, 1);
        }
      }

      // Render Player Bird
      drawBird(s.bird);

      // Render Ground on top of bottom pipes
      drawGround(s.groundOffset);

      // Pre-start helper instruction text if not started
      if (!s.hasStarted && s.isAlive && !s.isComplete) {
        ctx.save();
        ctx.textAlign = 'center';
        ctx.fillStyle = '#ffffff';
        ctx.shadowColor = 'rgba(0,0,0,0.7)';
        ctx.shadowBlur = 8;
        ctx.font = 'bold 22px "Fredoka", sans-serif';
        ctx.fillText('TAP OR PRESS SPACE', VIRTUAL_WIDTH / 2, 380);
        ctx.font = '600 15px "Plus Jakarta Sans", sans-serif';
        ctx.fillText(`Pass ${levelConfig.targetScore} pipes to complete Level ${levelConfig.level}!`, VIRTUAL_WIDTH / 2, 410);
        ctx.restore();
      }

      animationFrameId = requestAnimationFrame(render);
    };

    animationFrameId = requestAnimationFrame(render);

    return () => {
      cancelAnimationFrame(animationFrameId);
    };
  }, [levelConfig, isPaused]);

  return (
    <div
      ref={containerRef}
      className="relative w-full h-full max-w-[420px] max-h-[700px] flex items-center justify-center select-none overflow-hidden touch-none"
      onClick={handleFlap}
      onTouchStart={(e) => {
        // Prevent default double-tap zoom
        e.preventDefault();
        handleFlap();
      }}
    >
      <canvas
        ref={canvasRef}
        width={380}
        height={620}
        className="w-full h-full object-contain rounded-xl shadow-2xl bg-[#4ec0ca]"
      />
    </div>
  );
};
