/**
 * Sky Hopper - Main Menu Screen
 * Faithfully matches the vibrant retro arcade title screen from "sky hopper.mp4":
 * - Bright cyan sky, clouds, city silhouette
 * - Animated hovering blue bird
 * - Retro arcade "PLAY" button
 * - Levels button, How to Play, and Sound settings
 */

import React from 'react';
import { Play, Grid, HelpCircle, ArrowLeft, Trophy, Coins, Volume2, VolumeX } from 'lucide-react';
import { skyHopperAudio } from '../audio';

interface SkyHopperMainMenuProps {
  unlockedLevel: number;
  bestScore: number;
  totalCoins: number;
  soundEnabled: boolean;
  onPlay: () => void;
  onOpenLevelSelect: () => void;
  onOpenHowToPlay: () => void;
  onToggleSound: () => void;
  onExit: () => void;
}

export const SkyHopperMainMenu: React.FC<SkyHopperMainMenuProps> = ({
  unlockedLevel,
  bestScore,
  totalCoins,
  soundEnabled,
  onPlay,
  onOpenLevelSelect,
  onOpenHowToPlay,
  onToggleSound,
  onExit,
}) => {
  return (
    <div className="relative w-full h-full max-w-[420px] max-h-[700px] flex flex-col items-center justify-between p-6 select-none overflow-hidden rounded-xl bg-gradient-to-b from-[#4ec0ca] via-[#5ccfe0] to-[#73bf2e] border-4 border-[#2b500c] shadow-2xl">
      {/* Parallax pixel background clouds & skyline silhouettes */}
      <div className="absolute inset-0 pointer-events-none opacity-40">
        <div className="absolute top-12 left-6 w-24 h-10 bg-white rounded-full blur-[0.5px]" />
        <div className="absolute top-24 right-8 w-32 h-12 bg-white rounded-full blur-[0.5px]" />
        <div className="absolute bottom-24 left-0 right-0 h-32 bg-[#7bcbb9] opacity-30" />
      </div>

      {/* Top Header Bar */}
      <div className="relative z-10 w-full flex items-center justify-between">
        <button
          onClick={() => {
            skyHopperAudio.playButtonClick();
            onExit();
          }}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-black/40 border border-white/30 text-white font-semibold text-xs hover:bg-black/60 active:scale-95 transition-all shadow"
        >
          <ArrowLeft size={16} />
          <span>PORTAL</span>
        </button>

        <div className="flex items-center gap-2">
          {/* Sound Toggle */}
          <button
            onClick={() => {
              skyHopperAudio.playButtonClick();
              onToggleSound();
            }}
            className="w-8 h-8 rounded-lg bg-black/40 border border-white/30 flex items-center justify-center text-white hover:bg-black/60 active:scale-95 transition-all"
            title="Toggle Sound"
          >
            {soundEnabled ? <Volume2 size={16} /> : <VolumeX size={16} className="text-red-400" />}
          </button>

          {/* Coin Badge */}
          <div className="flex items-center gap-1.5 bg-black/40 border-2 border-amber-400 px-3 py-1 rounded-full shadow">
            <div className="w-4 h-4 rounded-full bg-amber-400 flex items-center justify-center text-[9px] font-black text-amber-950">
              ★
            </div>
            <span className="font-['Fredoka',sans-serif] text-sm font-bold text-white">
              {totalCoins}
            </span>
          </div>
        </div>
      </div>

      {/* Center Branding & Animated Mascot */}
      <div className="relative z-10 flex flex-col items-center mt-2">
        {/* Game Title Logo */}
        <div className="relative text-center mb-6">
          <h1
            className="font-['Fredoka',sans-serif] text-5xl font-black text-amber-300 tracking-wider uppercase"
            style={{
              textShadow:
                '-4px -4px 0 #1e3a0c, 4px -4px 0 #1e3a0c, -4px 4px 0 #1e3a0c, 4px 4px 0 #1e3a0c, 0 6px 0 #0f2005, 0 8px 16px rgba(0,0,0,0.5)',
            }}
          >
            Sky Hopper
          </h1>
          <span className="inline-block mt-1 px-3 py-0.5 rounded-full bg-white/20 border border-white/40 text-xs font-bold text-white tracking-widest uppercase shadow">
            40 Level Challenge
          </span>
        </div>

        {/* Mascot Bird with Gentle Hover & Flap */}
        <div className="relative w-28 h-28 flex items-center justify-center animate-bounce duration-1000">
          <svg viewBox="0 0 100 80" className="w-24 h-20 filter drop-shadow-xl">
            {/* Outline Body */}
            <ellipse cx="48" cy="42" rx="32" ry="24" fill="#17202a" />
            {/* Blue Body */}
            <ellipse cx="48" cy="42" rx="29" ry="21" fill="#38bdf8" />
            {/* Tail */}
            <path d="M 12 38 L 22 36 L 22 48 Z" fill="#0284c7" stroke="#17202a" strokeWidth="2" />
            {/* White Belly */}
            <ellipse cx="42" cy="50" rx="16" ry="11" fill="#ffffff" />
            {/* White Wing */}
            <ellipse cx="36" cy="40" rx="14" ry="8" transform="rotate(-10 36 40)" fill="#ffffff" stroke="#17202a" strokeWidth="2.5" />
            <path d="M 32 40 L 40 40" stroke="#0284c7" strokeWidth="3" strokeLinecap="round" />
            {/* Big Round Eye */}
            <circle cx="66" cy="32" r="11" fill="#17202a" />
            <circle cx="66" cy="32" r="9" fill="#ffffff" />
            <circle cx="68" cy="32" r="4.5" fill="#17202a" />
            <circle cx="66.5" cy="30" r="2" fill="#ffffff" />
            {/* Orange Beak */}
            <polygon points="76,34 94,40 76,48" fill="#f97316" stroke="#17202a" strokeWidth="2.5" />
            <line x1="76" y1="41" x2="88" y2="41" stroke="#c2410c" strokeWidth="2" />
          </svg>
        </div>

        {/* Stats Pill */}
        <div className="mt-4 flex items-center gap-4 bg-black/40 backdrop-blur-sm border border-white/20 px-4 py-2 rounded-xl text-white text-xs font-semibold shadow-inner">
          <div className="flex items-center gap-1.5">
            <Trophy size={14} className="text-amber-400" />
            <span>Best: <strong className="text-amber-300 font-bold text-sm">{bestScore}</strong></span>
          </div>
          <div className="h-3 w-px bg-white/30" />
          <div className="flex items-center gap-1.5">
            <Grid size={14} className="text-emerald-400" />
            <span>Progress: <strong className="text-emerald-300 font-bold text-sm">Level {unlockedLevel}/40</strong></span>
          </div>
        </div>
      </div>

      {/* Bottom Menu Buttons (Faithful to video styling) */}
      <div className="relative z-10 w-full flex flex-col gap-3 max-w-[280px]">
        {/* Big Retro Arcade PLAY Button */}
        <button
          onClick={() => {
            skyHopperAudio.playButtonClick();
            onPlay();
          }}
          className="w-full py-4 rounded-xl bg-white border-4 border-[#1e3a0c] shadow-[0_6px_0_#1e3a0c] active:translate-y-1 active:shadow-[0_2px_0_#1e3a0c] flex items-center justify-center gap-2 group transition-all"
        >
          <Play size={24} className="fill-[#1e3a0c] text-[#1e3a0c] group-hover:scale-110 transition-transform" />
          <span className="font-['Fredoka',sans-serif] text-2xl font-black text-[#1e3a0c] tracking-widest uppercase">
            PLAY
          </span>
        </button>

        {/* Level Select & How to Play Buttons */}
        <div className="grid grid-cols-2 gap-2.5">
          <button
            onClick={() => {
              skyHopperAudio.playButtonClick();
              onOpenLevelSelect();
            }}
            className="py-3 rounded-xl bg-[#f97316] border-3 border-[#1e3a0c] shadow-[0_4px_0_#1e3a0c] active:translate-y-1 active:shadow-[0_1px_0_#1e3a0c] text-white flex items-center justify-center gap-1.5 hover:brightness-105 transition-all"
          >
            <Grid size={18} />
            <span className="font-['Fredoka',sans-serif] text-sm font-bold tracking-wider">
              LEVELS
            </span>
          </button>

          <button
            onClick={() => {
              skyHopperAudio.playButtonClick();
              onOpenHowToPlay();
            }}
            className="py-3 rounded-xl bg-[#8b5cf6] border-3 border-[#1e3a0c] shadow-[0_4px_0_#1e3a0c] active:translate-y-1 active:shadow-[0_1px_0_#1e3a0c] text-white flex items-center justify-center gap-1.5 hover:brightness-105 transition-all"
          >
            <HelpCircle size={18} />
            <span className="font-['Fredoka',sans-serif] text-sm font-bold tracking-wider">
              HOW TO PLAY
            </span>
          </button>
        </div>
      </div>
    </div>
  );
};
