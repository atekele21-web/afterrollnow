/**
 * Sky Hopper - Dedicated 40-Level Selection Screen
 * Enforces strict, real level locking:
 * - Level 1 is unlocked initially
 * - Levels 2-40 are locked initially
 * - Locked levels show lock icon and strictly cannot be launched
 */

import React, { useState } from 'react';
import { ArrowLeft, Lock, Star, CheckCircle, Trophy, Sparkles } from 'lucide-react';
import { SKY_HOPPER_LEVELS } from '../levels';
import { skyHopperAudio } from '../audio';

interface SkyHopperLevelSelectProps {
  unlockedLevel: number;
  levelStars: Record<number, number>;
  onSelectLevel: (levelNumber: number) => void;
  onBack: () => void;
}

export const SkyHopperLevelSelect: React.FC<SkyHopperLevelSelectProps> = ({
  unlockedLevel,
  levelStars,
  onSelectLevel,
  onBack,
}) => {
  const [lockedShakeId, setLockedShakeId] = useState<number | null>(null);

  const handleLevelClick = (levelNumber: number) => {
    if (levelNumber > unlockedLevel) {
      // Locked! Real enforcement
      skyHopperAudio.playHit();
      setLockedShakeId(levelNumber);
      setTimeout(() => setLockedShakeId(null), 500);
      return;
    }

    // Unlocked!
    skyHopperAudio.playButtonClick();
    onSelectLevel(levelNumber);
  };

  return (
    <div className="relative w-full h-full max-w-[420px] max-h-[700px] flex flex-col p-4 select-none overflow-hidden rounded-xl bg-gradient-to-b from-[#4ec0ca] via-[#38bdf8] to-[#1e3a0c] border-4 border-[#1e3a0c] shadow-2xl">
      {/* Top Header */}
      <div className="flex items-center justify-between pb-3 border-b-2 border-white/20">
        <button
          onClick={() => {
            skyHopperAudio.playButtonClick();
            onBack();
          }}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-black/40 border border-white/30 text-white font-semibold text-xs hover:bg-black/60 active:scale-95 transition-all shadow"
        >
          <ArrowLeft size={16} />
          <span>MENU</span>
        </button>

        <div className="flex flex-col items-center">
          <h2 className="font-['Fredoka',sans-serif] text-2xl font-black text-amber-300 drop-shadow-[0_2px_4px_rgba(0,0,0,0.6)] uppercase tracking-wide">
            Select Level
          </h2>
          <span className="text-[11px] font-bold text-white/90">
            {unlockedLevel} / 40 Unlocked
          </span>
        </div>

        <div className="w-16 flex justify-end">
          <div className="flex items-center gap-1 bg-black/30 px-2 py-1 rounded-full border border-amber-400/40">
            <Trophy size={13} className="text-amber-400" />
            <span className="text-xs font-bold text-white">
              {Object.keys(levelStars).length}
            </span>
          </div>
        </div>
      </div>

      {/* 40-Level Grid (Scrollable, 4 columns) */}
      <div className="flex-1 overflow-y-auto py-4 px-1 pr-1.5 space-y-4">
        {/* Tier Groupings */}
        {[
          { title: 'Beginner (Levels 1 - 10)', min: 1, max: 10, color: 'text-emerald-300' },
          { title: 'Intermediate (Levels 11 - 20)', min: 11, max: 20, color: 'text-sky-300' },
          { title: 'Challenger (Levels 21 - 30)', min: 21, max: 30, color: 'text-amber-300' },
          { title: 'Grandmaster (Levels 31 - 40)', min: 31, max: 40, color: 'text-rose-300' },
        ].map((tier) => (
          <div key={tier.title} className="bg-black/25 backdrop-blur-sm p-3 rounded-xl border border-white/15">
            <div className="flex items-center justify-between mb-2 px-1">
              <span className={`text-xs font-bold tracking-wider uppercase ${tier.color}`}>
                {tier.title}
              </span>
            </div>

            <div className="grid grid-cols-5 gap-2">
              {SKY_HOPPER_LEVELS.filter((l) => l.level >= tier.min && l.level <= tier.max).map((lvl) => {
                const isUnlocked = lvl.level <= unlockedLevel;
                const isCompleted = (levelStars[lvl.level] || 0) > 0 || lvl.level < unlockedLevel;
                const starsCount = levelStars[lvl.level] || (isCompleted ? 3 : 0);
                const isShaking = lockedShakeId === lvl.level;

                return (
                  <button
                    key={lvl.level}
                    disabled={!isUnlocked}
                    onClick={() => handleLevelClick(lvl.level)}
                    className={`relative aspect-square rounded-xl flex flex-col items-center justify-center transition-all ${
                      isUnlocked
                        ? lvl.level === unlockedLevel
                          ? 'bg-gradient-to-b from-amber-300 to-amber-500 border-2 border-white shadow-[0_4px_0_#92400e] text-amber-950 font-black scale-105 ring-2 ring-amber-300 active:translate-y-1'
                          : 'bg-gradient-to-b from-white to-slate-200 border-2 border-[#1e3a0c] shadow-[0_3px_0_#1e3a0c] text-[#1e3a0c] font-black hover:scale-105 active:translate-y-1'
                        : 'bg-black/50 border border-white/10 text-white/30 cursor-not-allowed opacity-75'
                    } ${isShaking ? 'animate-shake ring-2 ring-red-500' : ''}`}
                  >
                    {isUnlocked ? (
                      <>
                        <span className="font-['Fredoka',sans-serif] text-base leading-none">
                          {lvl.level}
                        </span>
                        {/* Stars indicator if completed */}
                        {isCompleted && (
                          <div className="flex items-center gap-0.5 mt-1">
                            {[1, 2, 3].map((s) => (
                              <Star
                                key={s}
                                size={7}
                                className={s <= starsCount ? 'fill-amber-400 text-amber-400' : 'text-slate-400'}
                              />
                            ))}
                          </div>
                        )}
                        {lvl.level === unlockedLevel && !isCompleted && (
                          <span className="text-[8px] font-bold text-amber-900 mt-0.5 uppercase tracking-tighter">
                            PLAY
                          </span>
                        )}
                      </>
                    ) : (
                      <div className="flex flex-col items-center justify-center">
                        <Lock size={15} className="text-white/40 mb-0.5" />
                        <span className="text-[10px] font-bold text-white/40">
                          {lvl.level}
                        </span>
                      </div>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      {/* Footer Instructions */}
      <div className="pt-2 text-center border-t border-white/10">
        <p className="text-[11px] text-white/80 font-medium">
          Pass all pipes in each level to unlock the next challenge!
        </p>
      </div>
    </div>
  );
};
