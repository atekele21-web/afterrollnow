/**
 * Sky Hopper - Game Over Screen
 * Faithful recreation of the Game Over parchment board in "sky hopper.mp4":
 * - "Game Over" title in retro arcade gradient
 * - Tan parchment score card with MEDAL, SCORE, and BEST
 * - Floating coin counter (+N)
 * - "PLAY AGAIN" and "MENU" retro arcade buttons
 */

import React from 'react';
import { RotateCcw, Grid, Home, Award } from 'lucide-react';
import { skyHopperAudio } from '../audio';

interface SkyHopperGameOverProps {
  level: number;
  score: number;
  bestScore: number;
  coinsEarned: number;
  targetScore: number;
  onPlayAgain: () => void;
  onOpenLevelSelect: () => void;
  onMainMenu: () => void;
}

export const SkyHopperGameOver: React.FC<SkyHopperGameOverProps> = ({
  level,
  score,
  bestScore,
  coinsEarned,
  targetScore,
  onPlayAgain,
  onOpenLevelSelect,
  onMainMenu,
}) => {
  // Medal determination based on score
  const getMedalColor = () => {
    if (score >= targetScore) return { bg: 'from-amber-300 to-yellow-500', border: 'border-yellow-200', text: 'GOLD' };
    if (score >= Math.floor(targetScore * 0.7)) return { bg: 'from-slate-200 to-slate-400', border: 'border-slate-100', text: 'SILVER' };
    if (score >= Math.floor(targetScore * 0.4)) return { bg: 'from-amber-600 to-amber-800', border: 'border-amber-500', text: 'BRONZE' };
    return null;
  };

  const medal = getMedalColor();

  return (
    <div className="absolute inset-0 z-40 bg-black/60 backdrop-blur-sm flex flex-col items-center justify-center p-4 animate-in fade-in duration-200 select-none">
      {/* Container Box */}
      <div className="w-full max-w-[320px] flex flex-col items-center">
        {/* "Game Over" Title */}
        <h2
          className="font-['Fredoka',sans-serif] text-5xl font-black text-amber-500 uppercase tracking-wider mb-3 text-center"
          style={{
            textShadow:
              '-3px -3px 0 #1e3a0c, 3px -3px 0 #1e3a0c, -3px 3px 0 #1e3a0c, 3px 3px 0 #1e3a0c, 0 5px 0 #0f2005, 0 8px 12px rgba(0,0,0,0.6)',
          }}
        >
          Game Over
        </h2>

        {/* Tan Parchment Score Board (Identical to video reference) */}
        <div className="w-full bg-[#f4e8c1] border-4 border-[#5d4037] rounded-2xl p-4 shadow-[0_8px_0_#3e2723] mb-4">
          <div className="flex items-center justify-between gap-4">
            {/* Left: MEDAL Slot */}
            <div className="flex flex-col items-center justify-center w-24">
              <span className="font-['Fredoka',sans-serif] text-xs font-bold text-[#8d6e63] tracking-widest uppercase mb-1">
                MEDAL
              </span>
              <div className="w-16 h-16 rounded-full bg-[#d7ccc8] border-3 border-[#8d6e63] shadow-inner flex items-center justify-center">
                {medal ? (
                  <div className={`w-12 h-12 rounded-full bg-gradient-to-tr ${medal.bg} border-2 ${medal.border} shadow-md flex items-center justify-center animate-pulse`}>
                    <Award size={22} className="text-amber-950" />
                  </div>
                ) : (
                  <div className="w-10 h-10 rounded-full bg-[#bcaaa4] opacity-50" />
                )}
              </div>
              {medal && (
                <span className="text-[10px] font-black text-[#5d4037] mt-1 tracking-wider uppercase">
                  {medal.text}
                </span>
              )}
            </div>

            {/* Right: SCORE & BEST Numbers */}
            <div className="flex-1 flex flex-col items-end space-y-2 pr-2">
              <div className="flex flex-col items-end">
                <span className="font-['Fredoka',sans-serif] text-xs font-bold text-[#8d6e63] tracking-widest uppercase">
                  SCORE
                </span>
                <span
                  className="font-['Fredoka',sans-serif] text-3xl font-black text-white"
                  style={{
                    textShadow:
                      '-2px -2px 0 #3e2723, 2px -2px 0 #3e2723, -2px 2px 0 #3e2723, 2px 2px 0 #3e2723',
                  }}
                >
                  {score}
                </span>
              </div>

              <div className="w-full h-px bg-[#d7ccc8]" />

              <div className="flex flex-col items-end">
                <span className="font-['Fredoka',sans-serif] text-xs font-bold text-[#8d6e63] tracking-widest uppercase">
                  BEST
                </span>
                <span
                  className="font-['Fredoka',sans-serif] text-2xl font-black text-[#f59e0b]"
                  style={{
                    textShadow:
                      '-2px -2px 0 #3e2723, 2px -2px 0 #3e2723, -2px 2px 0 #3e2723, 2px 2px 0 #3e2723',
                  }}
                >
                  {bestScore}
                </span>
              </div>
            </div>
          </div>

          {/* Level Info Banner */}
          <div className="mt-3 pt-2 border-t border-[#d7ccc8] flex items-center justify-between text-xs font-bold text-[#5d4037]">
            <span>Level {level}</span>
            <span>Target: {targetScore} pipes</span>
          </div>
        </div>

        {/* Floating Coin Reward Row (From video: "+N") */}
        <div className="flex items-center justify-center gap-2 mb-4 bg-black/40 px-4 py-1.5 rounded-full border border-amber-400/40">
          <div className="w-5 h-5 rounded-full bg-gradient-to-tr from-amber-500 to-yellow-300 border border-yellow-100 flex items-center justify-center shadow">
            <span className="text-[10px] font-black text-amber-950">★</span>
          </div>
          <span className="font-['Fredoka',sans-serif] text-base font-bold text-amber-300">
            +{coinsEarned} Coins
          </span>
        </div>

        {/* Action Buttons */}
        <div className="w-full flex items-center gap-3">
          {/* PLAY AGAIN */}
          <button
            onClick={() => {
              skyHopperAudio.playButtonClick();
              onPlayAgain();
            }}
            className="flex-1 py-3.5 rounded-xl bg-gradient-to-b from-[#f97316] to-[#c2410c] border-3 border-[#1e3a0c] shadow-[0_5px_0_#1e3a0c] active:translate-y-1 active:shadow-[0_1px_0_#1e3a0c] text-white flex items-center justify-center gap-1.5 hover:brightness-105 transition-all"
          >
            <RotateCcw size={18} />
            <span className="font-['Fredoka',sans-serif] text-base font-bold tracking-wider uppercase">
              PLAY AGAIN
            </span>
          </button>

          {/* MENU / LEVELS */}
          <button
            onClick={() => {
              skyHopperAudio.playButtonClick();
              onOpenLevelSelect();
            }}
            className="py-3.5 px-4 rounded-xl bg-[#5d4037] border-3 border-[#1e3a0c] shadow-[0_5px_0_#1e3a0c] active:translate-y-1 active:shadow-[0_1px_0_#1e3a0c] text-white flex items-center justify-center gap-1.5 hover:brightness-110 transition-all"
          >
            <Grid size={18} />
            <span className="font-['Fredoka',sans-serif] text-sm font-bold tracking-wider uppercase">
              LEVELS
            </span>
          </button>
        </div>
      </div>
    </div>
  );
};
