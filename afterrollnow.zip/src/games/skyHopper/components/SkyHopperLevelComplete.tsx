/**
 * Sky Hopper - Level Complete Screen
 * Shown upon passing target number of pipes for the level.
 * Features:
 * - "LEVEL COMPLETE" fanfare banner
 * - 3-Star achievement rating
 * - Next Level Unlocked celebration
 * - "NEXT LEVEL" and "LEVEL SELECT" buttons
 */

import React from 'react';
import { Play, Grid, Star, Award, Coins } from 'lucide-react';
import { skyHopperAudio } from '../audio';

interface SkyHopperLevelCompleteProps {
  level: number;
  score: number;
  coinsEarned: number;
  starsEarned: number;
  onNextLevel: () => void;
  onOpenLevelSelect: () => void;
}

export const SkyHopperLevelComplete: React.FC<SkyHopperLevelCompleteProps> = ({
  level,
  score,
  coinsEarned,
  starsEarned,
  onNextLevel,
  onOpenLevelSelect,
}) => {
  return (
    <div className="absolute inset-0 z-40 bg-black/65 backdrop-blur-sm flex flex-col items-center justify-center p-4 animate-in zoom-in-95 duration-200 select-none">
      <div className="w-full max-w-[320px] flex flex-col items-center">
        {/* Level Complete Title */}
        <h2
          className="font-['Fredoka',sans-serif] text-4xl font-black text-amber-300 uppercase tracking-wider mb-2 text-center"
          style={{
            textShadow:
              '-3px -3px 0 #1e3a0c, 3px -3px 0 #1e3a0c, -3px 3px 0 #1e3a0c, 3px 3px 0 #1e3a0c, 0 5px 0 #0f2005, 0 8px 16px rgba(0,0,0,0.6)',
          }}
        >
          Level Complete!
        </h2>
        <span className="text-sm font-bold text-white mb-3">
          Level {level} Conquered
        </span>

        {/* Parchment Box */}
        <div className="w-full bg-[#f4e8c1] border-4 border-[#1e3a0c] rounded-2xl p-4 shadow-[0_8px_0_#1e3a0c] mb-4 flex flex-col items-center">
          {/* 3 Stars Award */}
          <div className="flex items-center gap-3 my-2">
            {[1, 2, 3].map((star) => (
              <div
                key={star}
                className={`transform transition-transform ${
                  star === 2 ? '-translate-y-2 scale-125' : ''
                }`}
              >
                <div
                  className={`w-12 h-12 rounded-full flex items-center justify-center ${
                    star <= starsEarned
                      ? 'bg-gradient-to-tr from-amber-500 to-yellow-300 border-2 border-yellow-200 shadow-md'
                      : 'bg-stone-300/80 border-2 border-stone-400'
                  }`}
                >
                  <Star
                    size={24}
                    className={
                      star <= starsEarned
                        ? 'fill-amber-900 text-amber-900'
                        : 'text-stone-400'
                    }
                  />
                </div>
              </div>
            ))}
          </div>

          {/* Stats summary */}
          <div className="w-full grid grid-cols-2 gap-2 mt-4 pt-3 border-t border-[#d7ccc8] text-center">
            <div className="bg-black/5 p-2 rounded-lg">
              <span className="text-[10px] font-bold text-[#8d6e63] uppercase tracking-wider block">
                Score
              </span>
              <span className="font-['Fredoka',sans-serif] text-xl font-black text-[#5d4037]">
                {score}
              </span>
            </div>

            <div className="bg-black/5 p-2 rounded-lg">
              <span className="text-[10px] font-bold text-[#8d6e63] uppercase tracking-wider block">
                Coins Collected
              </span>
              <span className="font-['Fredoka',sans-serif] text-xl font-black text-amber-700">
                +{coinsEarned}
              </span>
            </div>
          </div>

          <div className="mt-3 text-xs font-bold text-emerald-700 bg-emerald-100 px-3 py-1 rounded-full border border-emerald-300">
            ★ Level {Math.min(40, level + 1)} Unlocked!
          </div>
        </div>

        {/* Buttons */}
        <div className="w-full flex items-center gap-3">
          {/* NEXT LEVEL */}
          <button
            onClick={() => {
              skyHopperAudio.playButtonClick();
              onNextLevel();
            }}
            className="flex-1 py-3.5 rounded-xl bg-gradient-to-b from-[#84cc16] to-[#4d7c0f] border-3 border-[#1e3a0c] shadow-[0_5px_0_#1e3a0c] active:translate-y-1 active:shadow-[0_1px_0_#1e3a0c] text-white flex items-center justify-center gap-2 hover:brightness-105 transition-all"
          >
            <Play size={20} className="fill-white" />
            <span className="font-['Fredoka',sans-serif] text-base font-bold tracking-wider uppercase">
              NEXT LEVEL
            </span>
          </button>

          {/* LEVEL SELECT */}
          <button
            onClick={() => {
              skyHopperAudio.playButtonClick();
              onOpenLevelSelect();
            }}
            className="py-3.5 px-4 rounded-xl bg-[#5d4037] border-3 border-[#1e3a0c] shadow-[0_5px_0_#1e3a0c] active:translate-y-1 active:shadow-[0_1px_0_#1e3a0c] text-white flex items-center justify-center gap-1.5 hover:brightness-110 transition-all"
          >
            <Grid size={18} />
            <span className="font-['Fredoka',sans-serif] text-sm font-bold tracking-wider uppercase">
              LEVELS
            </span>
          </button>
        </div>
      </div>
    </div>
  );
};
