/**
 * Sky Hopper - In-Game Top HUD
 * Faithful recreation of the top HUD in "sky hopper.mp4":
 * - Left: Golden coin icon and collected count
 * - Center: Large retro white score with black outline
 * - Right: Orange square pause button
 */

import React from 'react';
import { Pause, Play, Volume2, VolumeX } from 'lucide-react';
import { skyHopperAudio } from '../audio';

interface SkyHopperTopHudProps {
  score: number;
  coins: number;
  isPaused: boolean;
  soundEnabled: boolean;
  onTogglePause: () => void;
  onToggleSound: () => void;
  onExit: () => void;
}

export const SkyHopperTopHud: React.FC<SkyHopperTopHudProps> = ({
  score,
  coins,
  isPaused,
  soundEnabled,
  onTogglePause,
  onToggleSound,
  onExit,
}) => {
  return (
    <div className="absolute top-0 left-0 right-0 z-30 flex items-center justify-between px-4 pt-3 pb-2 select-none pointer-events-none">
      {/* Left: Coin Badge */}
      <div className="flex items-center gap-2 pointer-events-auto">
        <div className="flex items-center gap-1.5 bg-black/40 backdrop-blur-sm border-2 border-[#f59e0b] px-3 py-1 rounded-full shadow-lg">
          <div className="w-5 h-5 rounded-full bg-gradient-to-tr from-amber-600 via-yellow-400 to-amber-200 border border-yellow-200 shadow flex items-center justify-center">
            <span className="text-[10px] font-black text-amber-900 leading-none">★</span>
          </div>
          <span className="font-['Fredoka',sans-serif] text-base font-bold text-white tracking-wide drop-shadow">
            {coins}
          </span>
        </div>
      </div>

      {/* Center: Large Retro Pixel-Arcade Score */}
      <div className="flex flex-col items-center pointer-events-none">
        <span
          className="font-['Fredoka',sans-serif] text-4xl sm:text-5xl font-black text-white tracking-wider"
          style={{
            textShadow:
              '-3px -3px 0 #000, 3px -3px 0 #000, -3px 3px 0 #000, 3px 3px 0 #000, 0px 4px 0 #000, 0 6px 12px rgba(0,0,0,0.5)',
          }}
        >
          {score}
        </span>
      </div>

      {/* Right: Orange Pause Button & Sound Toggle */}
      <div className="flex items-center gap-2 pointer-events-auto">
        <button
          onClick={(e) => {
            e.stopPropagation();
            onToggleSound();
          }}
          className="w-9 h-9 rounded-lg bg-black/40 border border-white/30 flex items-center justify-center text-white/90 hover:bg-black/60 active:scale-95 transition-transform shadow-md"
          title={soundEnabled ? 'Mute Sound' : 'Enable Sound'}
          aria-label="Toggle Sound"
        >
          {soundEnabled ? <Volume2 size={18} /> : <VolumeX size={18} className="text-red-400" />}
        </button>

        <button
          onClick={(e) => {
            e.stopPropagation();
            skyHopperAudio.playButtonClick();
            onTogglePause();
          }}
          className="w-10 h-10 rounded-lg bg-gradient-to-b from-[#f97316] to-[#c2410c] border-2 border-white/80 flex items-center justify-center text-white font-black shadow-lg hover:brightness-110 active:scale-95 transition-transform"
          title={isPaused ? 'Resume' : 'Pause'}
          aria-label="Pause Game"
        >
          {isPaused ? <Play size={20} className="fill-white translate-x-0.5" /> : <Pause size={20} className="fill-white" />}
        </button>
      </div>
    </div>
  );
};
