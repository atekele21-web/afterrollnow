/**
 * Sky Hopper - 40 Deterministic Level Configurations
 * Guaranteed fair, progressive, and strictly deterministic across gameplay sessions.
 */

import { SkyHopperLevelConfig, ObstacleDef } from './types';

// Deterministic generator with seeded pseudo-randomness for repeatable, tuned obstacle patterns
function createDeterministicObstacles(
  count: number,
  minHeight: number,
  maxHeight: number,
  coinFrequency: number,
  levelSeed: number
): ObstacleDef[] {
  const obstacles: ObstacleDef[] = [];
  let prevHeight = (minHeight + maxHeight) / 2;

  // Linear Congruential Generator for deterministic sequence
  let seed = levelSeed * 10007 + 37;
  const lcg = () => {
    seed = (seed * 1664525 + 1013904223) % 4294967296;
    return seed / 4294967296;
  };

  for (let i = 0; i < count; i++) {
    // Smooth step variation so consecutive pipes aren't absurdly discontinuous
    const rawDelta = (lcg() - 0.5) * 35;
    let targetH = prevHeight + rawDelta;
    if (targetH < minHeight) targetH = minHeight + lcg() * 10;
    if (targetH > maxHeight) targetH = maxHeight - lcg() * 10;
    prevHeight = targetH;

    const hasCoin = i % coinFrequency === 0 || lcg() < 0.45;
    const coinOffsetPercent = (lcg() - 0.5) * 15; // slightly up or down in the gap

    obstacles.push({
      topHeightPercent: Math.round(targetH * 10) / 10,
      hasCoin,
      coinOffsetPercent: Math.round(coinOffsetPercent * 10) / 10,
    });
  }

  return obstacles;
}

export const SKY_HOPPER_LEVELS: SkyHopperLevelConfig[] = [
  // ---------------------------------------------------------------------------
  // LEVEL 1–5: Beginner
  // ---------------------------------------------------------------------------
  {
    level: 1,
    name: 'First Flight',
    targetScore: 5,
    speed: 2.0,
    gapSize: 185,
    pipeSpacing: 280,
    gravity: 0.38,
    jumpForce: -7.2,
    obstacles: [
      { topHeightPercent: 35, hasCoin: true, coinOffsetPercent: 0 },
      { topHeightPercent: 40, hasCoin: true, coinOffsetPercent: 0 },
      { topHeightPercent: 35, hasCoin: false, coinOffsetPercent: 0 },
      { topHeightPercent: 42, hasCoin: true, coinOffsetPercent: 0 },
      { topHeightPercent: 38, hasCoin: true, coinOffsetPercent: 0 },
    ],
  },
  {
    level: 2,
    name: 'Gentle Breeze',
    targetScore: 6,
    speed: 2.05,
    gapSize: 180,
    pipeSpacing: 275,
    gravity: 0.38,
    jumpForce: -7.2,
    obstacles: [
      { topHeightPercent: 30, hasCoin: true, coinOffsetPercent: 0 },
      { topHeightPercent: 45, hasCoin: false, coinOffsetPercent: 0 },
      { topHeightPercent: 35, hasCoin: true, coinOffsetPercent: 0 },
      { topHeightPercent: 40, hasCoin: true, coinOffsetPercent: 0 },
      { topHeightPercent: 32, hasCoin: false, coinOffsetPercent: 0 },
      { topHeightPercent: 44, hasCoin: true, coinOffsetPercent: 0 },
    ],
  },
  {
    level: 3,
    name: 'Sunny Glade',
    targetScore: 6,
    speed: 2.1,
    gapSize: 176,
    pipeSpacing: 270,
    gravity: 0.38,
    jumpForce: -7.2,
    obstacles: [
      { topHeightPercent: 42, hasCoin: true, coinOffsetPercent: 0 },
      { topHeightPercent: 32, hasCoin: true, coinOffsetPercent: 0 },
      { topHeightPercent: 48, hasCoin: false, coinOffsetPercent: 0 },
      { topHeightPercent: 36, hasCoin: true, coinOffsetPercent: 0 },
      { topHeightPercent: 45, hasCoin: true, coinOffsetPercent: 0 },
      { topHeightPercent: 34, hasCoin: true, coinOffsetPercent: 0 },
    ],
  },
  {
    level: 4,
    name: 'Rolling Meadows',
    targetScore: 7,
    speed: 2.15,
    gapSize: 172,
    pipeSpacing: 265,
    gravity: 0.39,
    jumpForce: -7.2,
    obstacles: createDeterministicObstacles(7, 28, 52, 2, 104),
  },
  {
    level: 5,
    name: 'Skyward Rise',
    targetScore: 8,
    speed: 2.2,
    gapSize: 168,
    pipeSpacing: 260,
    gravity: 0.39,
    jumpForce: -7.2,
    obstacles: createDeterministicObstacles(8, 26, 54, 2, 105),
  },

  // ---------------------------------------------------------------------------
  // LEVEL 6–10: Easy/Intermediate
  // ---------------------------------------------------------------------------
  {
    level: 6,
    name: 'Cloud Peaks',
    targetScore: 9,
    speed: 2.25,
    gapSize: 165,
    pipeSpacing: 255,
    gravity: 0.39,
    jumpForce: -7.2,
    obstacles: createDeterministicObstacles(9, 25, 55, 2, 106),
  },
  {
    level: 7,
    name: 'Windy Valley',
    targetScore: 10,
    speed: 2.3,
    gapSize: 162,
    pipeSpacing: 250,
    gravity: 0.4,
    jumpForce: -7.3,
    obstacles: createDeterministicObstacles(10, 24, 56, 2, 107),
  },
  {
    level: 8,
    name: 'Emerald Ridge',
    targetScore: 10,
    speed: 2.32,
    gapSize: 160,
    pipeSpacing: 248,
    gravity: 0.4,
    jumpForce: -7.3,
    obstacles: createDeterministicObstacles(10, 24, 58, 2, 108),
  },
  {
    level: 9,
    name: 'High Horizons',
    targetScore: 11,
    speed: 2.35,
    gapSize: 158,
    pipeSpacing: 245,
    gravity: 0.4,
    jumpForce: -7.3,
    obstacles: createDeterministicObstacles(11, 23, 58, 2, 109),
  },
  {
    level: 10,
    name: 'Tower Ascent',
    targetScore: 12,
    speed: 2.38,
    gapSize: 155,
    pipeSpacing: 242,
    gravity: 0.4,
    jumpForce: -7.3,
    obstacles: createDeterministicObstacles(12, 22, 60, 2, 110),
  },

  // ---------------------------------------------------------------------------
  // LEVEL 11–15: Intermediate
  // ---------------------------------------------------------------------------
  {
    level: 11,
    name: 'Cobalt Skies',
    targetScore: 12,
    speed: 2.42,
    gapSize: 152,
    pipeSpacing: 240,
    gravity: 0.41,
    jumpForce: -7.3,
    obstacles: createDeterministicObstacles(12, 22, 60, 2, 111),
  },
  {
    level: 12,
    name: 'Acrobat Alley',
    targetScore: 13,
    speed: 2.45,
    gapSize: 150,
    pipeSpacing: 238,
    gravity: 0.41,
    jumpForce: -7.3,
    obstacles: createDeterministicObstacles(13, 21, 62, 2, 112),
  },
  {
    level: 13,
    name: 'Zigzag Flight',
    targetScore: 14,
    speed: 2.48,
    gapSize: 148,
    pipeSpacing: 235,
    gravity: 0.41,
    jumpForce: -7.35,
    obstacles: createDeterministicObstacles(14, 20, 62, 2, 113),
  },
  {
    level: 14,
    name: 'Rhythm Corridor',
    targetScore: 14,
    speed: 2.5,
    gapSize: 146,
    pipeSpacing: 232,
    gravity: 0.41,
    jumpForce: -7.35,
    obstacles: createDeterministicObstacles(14, 20, 64, 2, 114),
  },
  {
    level: 15,
    name: 'Skyline Dash',
    targetScore: 15,
    speed: 2.54,
    gapSize: 144,
    pipeSpacing: 230,
    gravity: 0.42,
    jumpForce: -7.4,
    obstacles: createDeterministicObstacles(15, 19, 64, 2, 115),
  },

  // ---------------------------------------------------------------------------
  // LEVEL 16–20: Intermediate/Hard
  // ---------------------------------------------------------------------------
  {
    level: 16,
    name: 'Breezy Gorge',
    targetScore: 15,
    speed: 2.58,
    gapSize: 142,
    pipeSpacing: 228,
    gravity: 0.42,
    jumpForce: -7.4,
    obstacles: createDeterministicObstacles(15, 19, 65, 2, 116),
  },
  {
    level: 17,
    name: 'Precision Pass',
    targetScore: 16,
    speed: 2.62,
    gapSize: 140,
    pipeSpacing: 225,
    gravity: 0.42,
    jumpForce: -7.4,
    obstacles: createDeterministicObstacles(16, 18, 65, 2, 117),
  },
  {
    level: 18,
    name: 'Emerald Slopes',
    targetScore: 16,
    speed: 2.65,
    gapSize: 138,
    pipeSpacing: 222,
    gravity: 0.43,
    jumpForce: -7.45,
    obstacles: createDeterministicObstacles(16, 18, 66, 2, 118),
  },
  {
    level: 19,
    name: 'Turbulence Lane',
    targetScore: 17,
    speed: 2.68,
    gapSize: 137,
    pipeSpacing: 220,
    gravity: 0.43,
    jumpForce: -7.45,
    obstacles: createDeterministicObstacles(17, 18, 66, 2, 119),
  },
  {
    level: 20,
    name: 'Midway Summit',
    targetScore: 18,
    speed: 2.72,
    gapSize: 135,
    pipeSpacing: 218,
    gravity: 0.43,
    jumpForce: -7.45,
    obstacles: createDeterministicObstacles(18, 17, 67, 2, 120),
  },

  // ---------------------------------------------------------------------------
  // LEVEL 21–25: Hard
  // ---------------------------------------------------------------------------
  {
    level: 21,
    name: 'Gilded Heights',
    targetScore: 18,
    speed: 2.76,
    gapSize: 134,
    pipeSpacing: 216,
    gravity: 0.44,
    jumpForce: -7.5,
    obstacles: createDeterministicObstacles(18, 17, 67, 2, 121),
  },
  {
    level: 22,
    name: 'Whirlwind Way',
    targetScore: 19,
    speed: 2.8,
    gapSize: 132,
    pipeSpacing: 214,
    gravity: 0.44,
    jumpForce: -7.5,
    obstacles: createDeterministicObstacles(19, 16, 68, 2, 122),
  },
  {
    level: 23,
    name: 'Narrow Canyon',
    targetScore: 19,
    speed: 2.84,
    gapSize: 130,
    pipeSpacing: 212,
    gravity: 0.44,
    jumpForce: -7.5,
    obstacles: createDeterministicObstacles(19, 16, 68, 2, 123),
  },
  {
    level: 24,
    name: 'Swift Flight',
    targetScore: 20,
    speed: 2.88,
    gapSize: 129,
    pipeSpacing: 210,
    gravity: 0.45,
    jumpForce: -7.55,
    obstacles: createDeterministicObstacles(20, 16, 68, 2, 124),
  },
  {
    level: 25,
    name: 'Skyline Labyrinth',
    targetScore: 20,
    speed: 2.92,
    gapSize: 128,
    pipeSpacing: 208,
    gravity: 0.45,
    jumpForce: -7.55,
    obstacles: createDeterministicObstacles(20, 15, 69, 2, 125),
  },

  // ---------------------------------------------------------------------------
  // LEVEL 26–30: Very Hard
  // ---------------------------------------------------------------------------
  {
    level: 26,
    name: 'Acrobat Elite',
    targetScore: 21,
    speed: 2.96,
    gapSize: 127,
    pipeSpacing: 206,
    gravity: 0.45,
    jumpForce: -7.55,
    obstacles: createDeterministicObstacles(21, 15, 69, 2, 126),
  },
  {
    level: 27,
    name: 'Razor Gap',
    targetScore: 21,
    speed: 3.0,
    gapSize: 126,
    pipeSpacing: 204,
    gravity: 0.46,
    jumpForce: -7.6,
    obstacles: createDeterministicObstacles(21, 15, 70, 2, 127),
  },
  {
    level: 28,
    name: 'High Altitude Pulse',
    targetScore: 22,
    speed: 3.04,
    gapSize: 125,
    pipeSpacing: 202,
    gravity: 0.46,
    jumpForce: -7.6,
    obstacles: createDeterministicObstacles(22, 15, 70, 2, 128),
  },
  {
    level: 29,
    name: 'Sonic Glide',
    targetScore: 22,
    speed: 3.08,
    gapSize: 124,
    pipeSpacing: 200,
    gravity: 0.46,
    jumpForce: -7.6,
    obstacles: createDeterministicObstacles(22, 15, 70, 2, 129),
  },
  {
    level: 30,
    name: 'Zenith Gauntlet',
    targetScore: 23,
    speed: 3.12,
    gapSize: 123,
    pipeSpacing: 198,
    gravity: 0.47,
    jumpForce: -7.65,
    obstacles: createDeterministicObstacles(23, 14, 71, 2, 130),
  },

  // ---------------------------------------------------------------------------
  // LEVEL 31–35: Expert
  // ---------------------------------------------------------------------------
  {
    level: 31,
    name: 'Aero Vanguard',
    targetScore: 24,
    speed: 3.16,
    gapSize: 122,
    pipeSpacing: 196,
    gravity: 0.47,
    jumpForce: -7.65,
    obstacles: createDeterministicObstacles(24, 14, 71, 2, 131),
  },
  {
    level: 32,
    name: 'Skyline Vortex',
    targetScore: 24,
    speed: 3.2,
    gapSize: 121,
    pipeSpacing: 194,
    gravity: 0.47,
    jumpForce: -7.65,
    obstacles: createDeterministicObstacles(24, 14, 72, 2, 132),
  },
  {
    level: 33,
    name: 'Split-Second Passage',
    targetScore: 25,
    speed: 3.24,
    gapSize: 120,
    pipeSpacing: 192,
    gravity: 0.48,
    jumpForce: -7.7,
    obstacles: createDeterministicObstacles(25, 14, 72, 2, 133),
  },
  {
    level: 34,
    name: 'Master Aviator',
    targetScore: 25,
    speed: 3.28,
    gapSize: 119,
    pipeSpacing: 190,
    gravity: 0.48,
    jumpForce: -7.7,
    obstacles: createDeterministicObstacles(25, 13, 72, 2, 134),
  },
  {
    level: 35,
    name: 'Celestial Run',
    targetScore: 26,
    speed: 3.32,
    gapSize: 118,
    pipeSpacing: 188,
    gravity: 0.48,
    jumpForce: -7.7,
    obstacles: createDeterministicObstacles(26, 13, 73, 2, 135),
  },

  // ---------------------------------------------------------------------------
  // LEVEL 36–39: Master
  // ---------------------------------------------------------------------------
  {
    level: 36,
    name: 'Stratosphere Needle',
    targetScore: 27,
    speed: 3.36,
    gapSize: 117,
    pipeSpacing: 186,
    gravity: 0.49,
    jumpForce: -7.75,
    obstacles: createDeterministicObstacles(27, 13, 73, 2, 136),
  },
  {
    level: 37,
    name: 'Tempest Spires',
    targetScore: 28,
    speed: 3.4,
    gapSize: 116,
    pipeSpacing: 184,
    gravity: 0.49,
    jumpForce: -7.75,
    obstacles: createDeterministicObstacles(28, 13, 73, 2, 137),
  },
  {
    level: 38,
    name: 'Apex Precision',
    targetScore: 28,
    speed: 3.44,
    gapSize: 115,
    pipeSpacing: 182,
    gravity: 0.49,
    jumpForce: -7.75,
    obstacles: createDeterministicObstacles(28, 12, 74, 2, 138),
  },
  {
    level: 39,
    name: 'Crown of Clouds',
    targetScore: 29,
    speed: 3.48,
    gapSize: 114,
    pipeSpacing: 180,
    gravity: 0.5,
    jumpForce: -7.8,
    obstacles: createDeterministicObstacles(29, 12, 74, 2, 139),
  },

  // ---------------------------------------------------------------------------
  // LEVEL 40: FINAL CHALLENGE
  // ---------------------------------------------------------------------------
  {
    level: 40,
    name: 'Grand Master Zenith',
    targetScore: 30,
    speed: 3.5,
    gapSize: 113,
    pipeSpacing: 178,
    gravity: 0.5,
    jumpForce: -7.8,
    obstacles: createDeterministicObstacles(30, 12, 75, 2, 140),
  },
];

export function getLevelConfig(levelNumber: number): SkyHopperLevelConfig {
  const index = Math.max(0, Math.min(39, levelNumber - 1));
  return SKY_HOPPER_LEVELS[index];
}
