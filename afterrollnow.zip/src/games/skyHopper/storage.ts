/**
 * Sky Hopper - Isolated Storage Management
 * Strictly isolated storage keys that do not overwrite any other game data.
 */

import { SkyHopperSaveData } from './types';

const STORAGE_KEYS = {
  UNLOCKED_LEVEL: 'skyHopperUnlockedLevel',
  BEST_SCORE: 'skyHopperBestScore',
  COINS: 'skyHopperCoins',
  STARS: 'skyHopperLevelStars',
  SOUND: 'skyHopperSoundEnabled',
};

export const SkyHopperStorage = {
  loadSaveData(): SkyHopperSaveData {
    try {
      const storedLevel = localStorage.getItem(STORAGE_KEYS.UNLOCKED_LEVEL);
      const unlockedLevel = storedLevel ? Math.max(1, Math.min(40, parseInt(storedLevel, 10) || 1)) : 1;

      const storedBest = localStorage.getItem(STORAGE_KEYS.BEST_SCORE);
      const bestScore = storedBest ? Math.max(0, parseInt(storedBest, 10) || 0) : 0;

      const storedCoins = localStorage.getItem(STORAGE_KEYS.COINS);
      const totalCoins = storedCoins ? Math.max(0, parseInt(storedCoins, 10) || 0) : 0;

      const storedStars = localStorage.getItem(STORAGE_KEYS.STARS);
      let levelStars: Record<number, number> = {};
      if (storedStars) {
        try {
          levelStars = JSON.parse(storedStars);
        } catch {
          levelStars = {};
        }
      }

      const storedSound = localStorage.getItem(STORAGE_KEYS.SOUND);
      const soundEnabled = storedSound !== null ? storedSound === 'true' : true;

      return {
        unlockedLevel,
        bestScore,
        totalCoins,
        levelStars,
        soundEnabled,
      };
    } catch (e) {
      console.warn('[SkyHopperStorage] Failed to read from localStorage', e);
      return {
        unlockedLevel: 1,
        bestScore: 0,
        totalCoins: 0,
        levelStars: {},
        soundEnabled: true,
      };
    }
  },

  unlockNextLevel(completedLevel: number): number {
    try {
      const current = this.loadSaveData().unlockedLevel;
      // If completed level is at or above current unlocked, unlock ONLY next level up to 40
      const nextLevel = Math.min(40, Math.max(current, completedLevel + 1));
      localStorage.setItem(STORAGE_KEYS.UNLOCKED_LEVEL, nextLevel.toString());
      return nextLevel;
    } catch {
      return Math.min(40, completedLevel + 1);
    }
  },

  updateBestScore(score: number): number {
    try {
      const currentBest = this.loadSaveData().bestScore;
      if (score > currentBest) {
        localStorage.setItem(STORAGE_KEYS.BEST_SCORE, score.toString());
        return score;
      }
      return currentBest;
    } catch {
      return score;
    }
  },

  addCoins(coinsEarned: number): number {
    try {
      const currentCoins = this.loadSaveData().totalCoins;
      const updated = currentCoins + coinsEarned;
      localStorage.setItem(STORAGE_KEYS.COINS, updated.toString());
      return updated;
    } catch {
      return coinsEarned;
    }
  },

  recordLevelStars(level: number, stars: number): Record<number, number> {
    try {
      const current = this.loadSaveData().levelStars;
      const prevStars = current[level] || 0;
      if (stars > prevStars) {
        current[level] = stars;
        localStorage.setItem(STORAGE_KEYS.STARS, JSON.stringify(current));
      }
      return current;
    } catch {
      return {};
    }
  },

  setSoundEnabled(enabled: boolean): void {
    try {
      localStorage.setItem(STORAGE_KEYS.SOUND, enabled ? 'true' : 'false');
    } catch {
      // noop
    }
  },
};
