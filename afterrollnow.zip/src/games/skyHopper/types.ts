/**
 * Sky Hopper - Isolated Types & Interfaces
 */

export interface ObstacleDef {
  topHeightPercent: number; // 15 to 65 (%)
  hasCoin?: boolean;
  coinOffsetPercent?: number; // offset from center of gap (-20 to +20)
}

export interface SkyHopperLevelConfig {
  level: number;
  name: string;
  targetScore: number; // number of pipe pairs to pass to complete level
  speed: number;       // horizontal obstacle speed
  gapSize: number;     // vertical gap in pixels (e.g. 170 for level 1, 112 for level 40)
  pipeSpacing: number; // horizontal distance between pipes in pixels (e.g. 260)
  gravity: number;
  jumpForce: number;
  obstacles: ObstacleDef[];
}

export interface SkyHopperSaveData {
  unlockedLevel: number; // 1 to 40
  bestScore: number;
  totalCoins: number;
  levelStars: Record<number, number>; // level -> 1, 2, or 3 stars
  soundEnabled: boolean;
}

export type SkyHopperScreen = 
  | 'MENU' 
  | 'LEVEL_SELECT' 
  | 'PLAYING' 
  | 'PAUSED' 
  | 'GAME_OVER' 
  | 'LEVEL_COMPLETE' 
  | 'ALL_COMPLETE' 
  | 'HOW_TO_PLAY';

export interface BirdEntity {
  x: number;
  y: number;
  vy: number;
  rotation: number;
  radius: number;
  wingPhase: number;
  isAlive: boolean;
}

export interface ActivePipe {
  index: number;
  x: number;
  topHeight: number;
  bottomY: number;
  gap: number;
  width: number;
  passed: boolean;
  hasCoin: boolean;
  coinCollected: boolean;
  coinX: number;
  coinY: number;
  coinRadius: number;
}

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  color: string;
  alpha: number;
  life: number;
  maxLife: number;
}

export interface FloatingText {
  x: number;
  y: number;
  text: string;
  color: string;
  alpha: number;
  life: number;
}
